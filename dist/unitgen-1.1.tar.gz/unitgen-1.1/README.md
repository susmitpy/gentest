# unitgen

Generate unit tests boilerplate code

Example
```bash
# View usage
unitgen

# all files under src directory are processed
unitgen src

# Files calci.py and pay_handler.py are processed
unitgen src/calci.py src/pay_handler.py
```

Acknowledgements
 - Idea inspired by Krishna Sonune who liked auto-generated boilerplate code for unit tests in Visual Studio for C #