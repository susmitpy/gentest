# gentest

Generate unit tests

Example
```bash
# View usage
python3 gentest.py

# all files under src directory are processed
python3 gentest.py src

# Files calci.py and pay_handler.py are processed
python3 gentest.py src/calci.py src/pay_handler.py
```