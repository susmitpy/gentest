# gentest

Generate unit tests

Example
```bash
# View usage
gentest

# all files under src directory are processed
gentest src

# Files calci.py and pay_handler.py are processed
gentest src/calci.py src/pay_handler.py
```

Acknowledgements
 - Idea inspired by Krishna Sonune who liked auto-generated boilerplate code in Visual Studio for C #